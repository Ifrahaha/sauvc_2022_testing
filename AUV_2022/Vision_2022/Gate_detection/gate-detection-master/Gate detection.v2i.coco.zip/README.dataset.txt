# Gate detection > 2022-04-10 5:07pm
https://universe.roboflow.com/object-detection/gate-detection-svm46

Provided by Roboflow
License: MIT

